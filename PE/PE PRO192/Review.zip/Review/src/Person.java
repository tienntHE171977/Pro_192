/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Person {
    // 1. Thuoc tinh
    // Nhung thong tin mo ta doi tuong do
    
    // Encapsulation - tinh dong goi: de bao ve du lieu ben trong khong duoc sua doi tuy tien
    // Pham vi truy xuat (access modifier)
    // private (-): chi duoc truy xuat trong class do
    // default (~): duoc truy xuat ngoai class nhung trong package
    // protected (#): duoc truy xuat ngoai package nhung voi dk la phai thong qua tinh ke thua
    // public (+): truy xuat thoai mai
    // - < ~ < # < +
    private String name;
    private int age;
    private String address;        
    
    // 2. Phuong thuc
    // 2 kieu phuong thuc
    // - Phuong thuc khoi tao (dung de khoi tao doi tuong)
    // - Phuong thuc con lai (void, int, boolean)
    
    // Phuong thuc khoi tao mac dinh - default constructor
    public Person() {        
    }
    
    // Phuong thuc khoi tao co tham so
    // this: tro toi lop hien tai
    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }
    
    // Doi voi tung kieu du lieu se co 2 phuong thuc nen co
    // getters (lay gia tri), setters (gan gia tri)
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;        
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    // Tat ca cac lop trong java deu la lop con cua Object
    // toString() - tra ve chuoi thong tin doi tuong
    @Override
    public String toString() {
        return name + ": " + age + ", " + address;
    }    
    
}
