
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        // Kien thuc co ban
        
        // Kieu du lieu co ban - primitive
        // So nguyen: int, long
        // So thuc: float, double
        // Ky tu: char, string
        // Dung sai: boolean
        
        // Cac kieu du lieu tu dinh nghia:
        // Student, Teacher, Worker
        
        // Nhap xuat du lieu (input. output)
        // Kieudulieu + ten = new Kieudulieu();
        Scanner sc = new Scanner(System.in);
//        System.out.print("Enter x = ");
//        String x = sc.nextLine();
//        char c = sc.nextLine().charAt(0);
        // truong dai hoc fpt
//        System.out.println("x + 10 = " + (x + 10));
        
        // if - else - else if
//        int x = sc.nextInt();
//        if (x > 10) {
//            System.out.println(x + " co gia tri lon hon 10");
//        } else if (x > 5) {
//            System.out.println(x + " lon hon 5 nhung nho 10");
//        } else {
//            System.out.println("TH con lai");
//        }

        // for - while - do while
        // for (khoi tao gia tri; dieu kien dung vong lap; buoc nhay) {}
//        int sum = 0;
//        for (int i = 1; i <= 10; i++) {
//            if (i % 2 != 0) {
//                sum = sum + i;
//                sum += i;
//            }
//        }
//        System.out.println(sum);

//        int i = 10;
//        while (dieu kien dung vong lap) {}
//        while (i < 10) {
//            System.out.println(i);
//            i++;
//        }

        // Thuc thi truoc it nhat 1 lan roi moi ktra dieu kien
//        do {
//            System.out.println("XIN CHAO");
//        } while (i < 5);        

        // break, continue
        // break: ket thuc vong lap ngay lap tuc
        // continue: bo qua vong lap hien tai va sang buoc nhay tiep theo
//        for (int i = 0; i < 10; i++) {
//            if (i == 5) {
//                continue;
//            }
//            System.out.println(i);
//        }
        
        // Trong mang thi chi so bat dau tu 0 -> n - 1
//        System.out.print("Enter n = ");
//        int n = sc.nextInt();
//        int[] a = new int[n];  // chi so tu 0 -> 9        
//        for (int i = 0; i < n; i++) {
//            System.out.print("Enter a[" + i + "] = ");
//            a[i] = sc.nextInt();
//        }
//        
//        System.out.println("Your array:");
//        for (int i = 0; i < n; i++) {
//            System.out.print(a[i] + " ");
//        }

        // Review OOP
        // . de lay ra thuoc tinh, phuong thuc cua doi tuong
        Person p = new Person("Tuan", 20, "Ha Noi");
        System.out.println(p);
        
        Student s = new Student("Quang", 30, "HCM", 9.9, "FPTU");
        System.out.println(s);
    }
}
