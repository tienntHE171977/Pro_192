/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Student extends Person {
    // Inheritance: tinh ke thua cho phep lop con ke thua lop cha
    // duoc huong het cac thuoc tinh, phuong thuc tu lop cha
    private double grade;
    private String school;

    public Student() {
    }

    public Student(String name, int age, String address, double grade, String school) {
        // this tro toi lop hien tai
        // super tro toi lop cha
        // super() de goi toi phuong thuc khoi tao cua lop cha (lenh nay PHAI O DONG DAU TIEN trong khoi tao)
        // super.() de goi toi cac phuong thuc con lai
        super(name, age, address);
        this.grade = grade;
        this.school = school;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }
    
    // Override - ghi de phuong thuc
    // Cho phep lop con chinh sua phuong thuc cua lop cha cung ten
    
    // && - and
    // || - or
    @Override
    public void setAge(int age) {
        if (0 < super.getAge() && super.getAge() < 18) {
            super.setAge(age);
        } else {
            System.out.println("INVALID");
        }
    }
    
    // Overload - nap chong phuong thuc
    // Cho phep cac phuong thuc cung ten va cung class thuc hien hanh vi khac nhau
    // Kieu du lieu tham so, so luong tham so, kieu tra ve
    int calculate(int a, int b) {
        return a + b;
    }
    
    double calculate(double a, double b, double c) {
        return a + b * c;
    }  

    @Override
    public String toString() {
        return super.toString() + ", " + grade + ", " + school;
    }
    
}
